package com.gunungbutak.terpadu;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter[] filters;
    private String[][] techLists;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            @SuppressWarnings("deprecation")
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(android.net.Uri.parse(url));
            }
        });
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new NfcBridge(), "AndroidNfc");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        pendingIntent = PendingIntent.getActivity(
            this, 0,
            new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
        );
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        filters = new IntentFilter[]{tagDetected};
        techLists = new String[][]{};
    }

    @Override protected void onResume() {
        super.onResume();
        if (nfcAdapter != null) {
            nfcAdapter.enableForegroundDispatch(this, pendingIntent, filters, techLists);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) nfcAdapter.disableForegroundDispatch(this);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (tag != null) {
            String uid = bytesToHex(tag.getId());
            String tech = joinTech(tag.getTechList());
            String js = "window.onNativeNfcRead && window.onNativeNfcRead(" +
                    JSONObjectLike.quote(uid) + "," + JSONObjectLike.quote(tech) + ")";
            webView.post(() -> webView.evaluateJavascript(js, null));
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder s = new StringBuilder();
        for (byte b : bytes) s.append(String.format(Locale.US, "%02X", b));
        return s.toString();
    }

    private static String joinTech(String[] a) {
        StringBuilder s = new StringBuilder();
        for (int i=0; i<a.length; i++) {
            if (i>0) s.append(", ");
            s.append(a[i]);
        }
        return s.toString();
    }

    public class NfcBridge {
        @JavascriptInterface public boolean isNfcAvailable() {
            return nfcAdapter != null;
        }
        @JavascriptInterface public boolean isNfcEnabled() {
            return nfcAdapter != null && nfcAdapter.isEnabled();
        }
        @JavascriptInterface public void openNfcSettings() {
            startActivity(new Intent(android.provider.Settings.ACTION_NFC_SETTINGS));
        }
    }

    static class JSONObjectLike {
        static String quote(String s) {
            return "'" + s.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","\\r") + "'";
        }
    }
}
