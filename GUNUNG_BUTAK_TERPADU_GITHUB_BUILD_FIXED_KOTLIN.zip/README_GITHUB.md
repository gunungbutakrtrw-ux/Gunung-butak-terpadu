# Gunung Butak Terpadu NFC - GitHub Build

This project is prepared to build an installable Android debug APK using GitHub Actions.

## Build from a phone
1. Create/sign in to a GitHub account.
2. Create a new repository, for example `gunung-butak-nfc`.
3. Upload all files and folders from this project ZIP (do not upload the ZIP as the only file).
4. Open the repository's **Actions** tab.
5. Select **Build Gunung Butak NFC APK** and run the workflow, or push to `main`.
6. When the job finishes successfully, open the workflow run and download the artifact named `GunungButakNFC-APK`.
7. Extract the artifact ZIP. Inside is `app-debug.apk`.
8. Install `app-debug.apk` on the Android phone.

## Important NFC note
The native Android layer reads the NFC tag UID/ID exposed by Android. It does not directly extract the NIK from the protected e-KTP chip. The UID can be paired with a resident/NIK in Firebase.
