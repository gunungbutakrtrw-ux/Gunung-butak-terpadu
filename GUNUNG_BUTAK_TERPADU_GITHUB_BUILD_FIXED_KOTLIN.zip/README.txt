GUNUNG BUTAK TERPADU - NFC NATIVE + FIREBASE

ALUR:
1. Login admin menggunakan Firebase Authentication.
2. Menu Portal -> Siapkan Pembaca NFC.
3. Tempel kartu NFC. Android membaca UID kartu.
4. Aplikasi mencari dokumen Firestore nfc_cards dengan field uid yang sama.
5. Dokumen harus memiliki field nik berisi NIK 16 digit.
6. NIK dicocokkan dengan koleksi warga. Jika cocok, portal dibuka dan akses dicatat.

CONTOH dokumen Firestore:
Collection: nfc_cards
Document ID: bebas
Fields:
uid: "04A1B2C3D4E5"
nik: "XXXXXXXXXXXXXXXX"

CATATAN PENTING:
- UID di contoh harus diganti UID kartu yang benar.
- NIK harus sama dengan NIK pada koleksi warga.
- Versi ini tidak membaca data rahasia chip e-KTP. Ia membaca UID NFC Android dan melakukan pemetaan ke NIK di Firebase.
- Build dengan Android Studio, lalu install APK pada HP yang memiliki NFC.
